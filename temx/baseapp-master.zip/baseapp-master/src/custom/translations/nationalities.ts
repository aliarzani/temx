export const customNationalitiesNames = {};
