export const ALERT_DELETE = 'alert/ALERT_DELETE';
export const ALERT_DATA = 'alert/ALERT_DATA';
export const ALERT_PUSH = 'alert/ALERT_PUSH';
export const ALERT_DELETE_BY_INDEX = 'alert/ALERT_DELETE_BY_INDEX';
