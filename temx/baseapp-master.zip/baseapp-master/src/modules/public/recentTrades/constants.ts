export const RECENT_TRADES_FETCH = 'recentTrades/FETCH';
export const RECENT_TRADES_DATA = 'recentTrades/DATA';
export const RECENT_TRADES_ERROR = 'recentTrades/ERROR';
export const RECENT_TRADES_PUSH = 'recentTrades/PUSH';
