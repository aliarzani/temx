export const SAVE_LAYOUTS = 'layouts/SAVE_LAYOUTS';
export const RESET_LAYOUTS = 'layouts/RESET_LAYOUTS';
