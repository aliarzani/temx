export const CURRENCIES_FETCH = 'currencies/FETCH';
export const CURRENCIES_DATA = 'currencies/DATA';
export const CURRENCIES_ERROR = 'currencies/ERROR';
