export const MEMBER_LEVELS_FETCH = 'memberLevels/FETCH';
export const MEMBER_LEVELS_DATA = 'memberLevels/DATA';
export const MEMBER_LEVELS_ERROR = 'memberLevels/ERROR';
