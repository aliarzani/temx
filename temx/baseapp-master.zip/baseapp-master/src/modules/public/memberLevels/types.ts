export interface MemberLevels {
    deposit: { minimum_level: number };
    withdraw: { minimum_level: number };
    trading: { minimum_level: number };
}
