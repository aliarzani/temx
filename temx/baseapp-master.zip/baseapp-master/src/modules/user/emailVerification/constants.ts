export const EMAIL_VERIFICATION_DATA = 'emailVerification/DATA';
export const EMAIL_VERIFICATION_ERROR = 'emailVerification/ERROR';
export const EMAIL_VERIFICATION_FETCH = 'emailVerification/FETCH';
