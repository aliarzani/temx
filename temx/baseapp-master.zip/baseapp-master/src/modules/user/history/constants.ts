export const HISTORY_FETCH = 'history/FETCH';
export const HISTORY_DATA  = 'history/DATA';
export const HISTORY_ERROR = 'history/ERROR';
export const HISTORY_RESET = 'history/RESET';
export const HISTORY_PUSH_EMIT = 'history/PUSH_EMIT';
export const HISTORY_PUSH_FINISH = 'history/PUSH_FINISH';
