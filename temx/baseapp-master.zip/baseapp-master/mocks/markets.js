module.exports = [
    'BTC/ZAR',
    'BCH/ZAR',
    'ETH/BTC',
    'DASH/BTC',
    'EUR/USD',
]
